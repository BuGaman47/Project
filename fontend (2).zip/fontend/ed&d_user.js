
let mode = 'CREATE'; 
let selectedID = null; 

const checkEditMode = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');
    console.log('ID:', userId);

    if (userId) {
        mode = 'EDIT';
        selectedID = userId;

        try {
            const response = await axios.get(`${BASE_URL}/tb_user/${userId}`);
            const user = response.data;
            document.querySelector('input[name=username]').value = user.username;
            document.querySelector('input[name=password]').value = user.password;
            // ตรวจสอบค่าของ role
            const roleDOMs = document.querySelectorAll('input[name="role"]');
            for (let i = 0; i < roleDOMs.length; i++) {
                if (roleDOMs[i].value === user.role) {
                    roleDOMs[i].checked = true;
                }
            }
            document.querySelector('input[name=tel]').value = user.tel;
        } catch (error) {
            console.log('Error fetching user data:', error);
        }
    }
};

// ฟังก์ชันตรวจสอบข้อมูลที่กรอก
const validateUserData = (userData) => {
    let errors = [];

    if (!userData.username) {
        errors.push('กรุณากรอกชื่อ');
    }
    if (!userData.password) {
        errors.push('กรุณากรอกรหัสผ่าน');
    }
    if (!userData.role) {
        errors.push('กรุณาเลือกบทบาท');
    }
    if (!userData.tel) {
        errors.push('กรุณากรอกเบอร์โทรศัพท์');
    }
    if (userData.tel && isNaN(userData.tel)) {
        errors.push('เบอร์โทรศัพท์ต้องเป็นตัวเลขเท่านั้น');
    }
    return errors;
};

// ฟังก์ชันส่งข้อมูลผู้ใช้
const submitData = async () => {
    let usernameDOM = document.querySelector('input[name=username]');
    let passwordDOM = document.querySelector('input[name=password]');
    let roleDOM = document.querySelector('input[name=role]:checked');
    let telDOM = document.querySelector('input[name=tel]');

    let messageDOM = document.getElementById('message');

    try {
        let userData = {
            username: usernameDOM.value,
            password: passwordDOM.value,
            role: roleDOM ? roleDOM.value : '',
            tel: telDOM.value
        };

        let message = 'บันทึกข้อมูลสำเร็จ';
        if (mode === 'CREATE') {
            await axios.post(`${BASE_URL}/tb_user`, userData); // ส่งข้อมูล POST
        } else {
            await axios.put(`${BASE_URL}/tb_user/${selectedID}`, userData); // ส่งข้อมูล PUT
            message = 'แก้ไขข้อมูลสำเร็จ';
        }

        messageDOM.innerText = message;
        messageDOM.className = "message success";

        loadData();

    } catch (error) {
        console.log('Error message:', error.message);

        let errorMessage = error.message;
        let errorList = [];

        if (error.response) {
            errorMessage = error.response.data.message || errorMessage;
            errorList = error.response.data.errors || [];
        }

        let htmlData = `<div>${errorMessage}</div><ul>`;
        errorList.forEach(err => {
            htmlData += `<li>${err}</li>`;
        });
        htmlData += '</ul>';

        messageDOM.innerHTML = htmlData;
        messageDOM.className = 'message danger'; 
    }
};

// ฟังก์ชันค้นหาผู้ใช้
const searchusers = async () => {
    const searchTerm = document.querySelector('input[name="search-username"]').value;
    try {
        const response = await axios.get(`${BASE_URL}/tb_user?search=${searchTerm}`);
        console.log(response.data);

        // แสดงผลการค้นหาผู้ใช้
        loadData(response.data);
    } catch (error) {
        console.error('Error searching for users:', error);
    }
};