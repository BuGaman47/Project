
let mode = 'CREATE'; 
let selectedID = null; 

const checkEditMode = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');
    console.log('ID:', id);

    if (userId) {
        mode = 'EDIT';
        selectedID = userId;

        try {
            const response = await axios.get(`${BASE_URL}/tb_booking/${userId}`);
            const user = response.data;

            document.querySelector('input[name=Name]').value = user.Name;
            document.querySelector('input[name=room_id]').value = user.room_id;
            document.querySelector('input[name=booking_date]').value = user.booking_date;
            document.querySelector('input[name=start_time]').value = user.start_time;
            document.querySelector('input[name=end_time]').value = user.end_time;
            document.querySelector('input[name=title]').value = user.title;
        } catch (error) {
            console.log('Error fetching user data:', error);
        }
    }
};

// ฟังก์ชันตรวจสอบข้อมูลที่กรอก
const validatebookingData = (bookingData) => {
    let errors = [];
    if (!bookingData.Name) {
        errors.push('กรุณากรอกชื่อ');
    }
    if (!bookingData.room_id) {
        errors.push('กรุณาเลือกห้อง');
    }
    if (!bookingData.booking_date) {
        errors.push('กรุณาเลือกวันที่');
    }
    if (!bookingData.start_time) {
        errors.push('กรุณาเลือกเวลาเริ่ม');
    }
    if (!bookingData.end_time) {
        errors.push('กรุณาเลือกเวลาสิ้นสุด');
    }
    if (!bookingData.title) {
        errors.push('กรุณากรอกหัวข้อ');
    }
    return errors;
};

// ฟังก์ชันส่งข้อมูลผู้ใช้
const submitData = async () => {
    let NameDOM = document.querySelector('input[name=Name]');
    let room_idDOM = document.querySelector('input[name=room_id]');
    let booking_dateDOM = document.querySelector('input[name=booking_date]');
    let start_timeDOM = document.querySelector('input[name=start_time]');
    let end_timeDOM = document.querySelector('input[name=end_time]');
    let titleDOM = document.querySelector('input[name=title]');
    
    let messageDOM = document.getElementById('message');

    try {
        let bookingData = {
            Name: NameDOM.value,
            room_id: room_idDOM.value,
            booking_date: booking_dateDOM.value,
            start_time: start_timeDOM.value,
            end_time: end_timeDOM.value,
            title: titleDOM.value
        };

        let message = 'บันทึกข้อมูลสำเร็จ';
        if (mode === 'CREATE') {
            await axios.post(`${BASE_URL}/tb_booking`, bookingData); // ส่งข้อมูล POST
        } else {
            await axios.put(`${BASE_URL}/tb_booking/${selectedID}`, bookingData); // ส่งข้อมูล PUT
            message = 'แก้ไขข้อมูลสำเร็จ';
        }

        messageDOM.innerText = message;
        messageDOM.className = "message success";

        loadData();

    } catch (error) {
        console.log('Error message:', error.message);

        let errorMessage = error.message;
        let errorList = [];

        if (error.response) {
            errorMessage = error.response.data.message || errorMessage;
            errorList = error.response.data.errors || [];
        }

        let htmlData = `<div>${errorMessage}</div><ul>`;
        errorList.forEach(err => {
            htmlData += `<li>${err}</li>`;
        });
        htmlData += '</ul>';

        messageDOM.innerHTML = htmlData;
        messageDOM.className = 'message danger'; 
    }
};
